	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Path_8", "4d536289-6fea-4617-b499-a4e879f6eb5b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "4d536289-6fea-4617-b499-a4e879f6eb5b"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_9", "4d536289-6fea-4617-b499-a4e879f6eb5b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "4d536289-6fea-4617-b499-a4e879f6eb5b"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_10", "4d536289-6fea-4617-b499-a4e879f6eb5b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "4d536289-6fea-4617-b499-a4e879f6eb5b"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_11", "4d536289-6fea-4617-b499-a4e879f6eb5b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "4d536289-6fea-4617-b499-a4e879f6eb5b"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Paragraph_1", "4d536289-6fea-4617-b499-a4e879f6eb5b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "4d536289-6fea-4617-b499-a4e879f6eb5b"]] = ["Title Button", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Path_1", "4d536289-6fea-4617-b499-a4e879f6eb5b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "4d536289-6fea-4617-b499-a4e879f6eb5b"]] = ["Home indicator", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_8", "3a408e4f-eb1f-437b-9041-e985802234ee"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "3a408e4f-eb1f-437b-9041-e985802234ee"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_9", "3a408e4f-eb1f-437b-9041-e985802234ee"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "3a408e4f-eb1f-437b-9041-e985802234ee"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_10", "3a408e4f-eb1f-437b-9041-e985802234ee"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "3a408e4f-eb1f-437b-9041-e985802234ee"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_11", "3a408e4f-eb1f-437b-9041-e985802234ee"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "3a408e4f-eb1f-437b-9041-e985802234ee"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Paragraph_1", "3a408e4f-eb1f-437b-9041-e985802234ee"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "3a408e4f-eb1f-437b-9041-e985802234ee"]] = ["Title Button", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Path_1", "3a408e4f-eb1f-437b-9041-e985802234ee"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "3a408e4f-eb1f-437b-9041-e985802234ee"]] = ["Home indicator", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_1", "1550d651-a200-4eaf-aba5-9a2aa9a1e732"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "1550d651-a200-4eaf-aba5-9a2aa9a1e732"]] = ["Status bar 2", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_2", "1550d651-a200-4eaf-aba5-9a2aa9a1e732"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "1550d651-a200-4eaf-aba5-9a2aa9a1e732"]] = ["Status bar 2", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_3", "1550d651-a200-4eaf-aba5-9a2aa9a1e732"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "1550d651-a200-4eaf-aba5-9a2aa9a1e732"]] = ["Status bar 2", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_4", "1550d651-a200-4eaf-aba5-9a2aa9a1e732"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "1550d651-a200-4eaf-aba5-9a2aa9a1e732"]] = ["Status bar 2", "s-Group_1"]; 

	widgets.descriptionMap[["s-Text_3", "1550d651-a200-4eaf-aba5-9a2aa9a1e732"]] = ""; 

			widgets.rootWidgetMap[["s-Text_3", "1550d651-a200-4eaf-aba5-9a2aa9a1e732"]] = ["Title Button", "s-Text_3"]; 

	widgets.descriptionMap[["s-Path_8", "ddfaf0c8-9066-452b-8cef-df295962c9d3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "ddfaf0c8-9066-452b-8cef-df295962c9d3"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_9", "ddfaf0c8-9066-452b-8cef-df295962c9d3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "ddfaf0c8-9066-452b-8cef-df295962c9d3"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_10", "ddfaf0c8-9066-452b-8cef-df295962c9d3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "ddfaf0c8-9066-452b-8cef-df295962c9d3"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_11", "ddfaf0c8-9066-452b-8cef-df295962c9d3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "ddfaf0c8-9066-452b-8cef-df295962c9d3"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Paragraph_1", "ddfaf0c8-9066-452b-8cef-df295962c9d3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "ddfaf0c8-9066-452b-8cef-df295962c9d3"]] = ["Title Button", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Path_1", "ddfaf0c8-9066-452b-8cef-df295962c9d3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "ddfaf0c8-9066-452b-8cef-df295962c9d3"]] = ["Home indicator", "s-Path_1"]; 

	widgets.descriptionMap[["s-Rect_8", "ca90d1c9-7c1f-4e09-8143-0defe2d7df92"]] = ""; 

			widgets.rootWidgetMap[["s-Rect_8", "ca90d1c9-7c1f-4e09-8143-0defe2d7df92"]] = ["Home indicator", "s-Rect_8"]; 

	widgets.descriptionMap[["s-Path_8", "ca90d1c9-7c1f-4e09-8143-0defe2d7df92"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "ca90d1c9-7c1f-4e09-8143-0defe2d7df92"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_9", "ca90d1c9-7c1f-4e09-8143-0defe2d7df92"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "ca90d1c9-7c1f-4e09-8143-0defe2d7df92"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_10", "ca90d1c9-7c1f-4e09-8143-0defe2d7df92"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "ca90d1c9-7c1f-4e09-8143-0defe2d7df92"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_11", "ca90d1c9-7c1f-4e09-8143-0defe2d7df92"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "ca90d1c9-7c1f-4e09-8143-0defe2d7df92"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Paragraph_1", "ca90d1c9-7c1f-4e09-8143-0defe2d7df92"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "ca90d1c9-7c1f-4e09-8143-0defe2d7df92"]] = ["Title Button", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Input_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Search", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Search", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Search", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Search", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title Button", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Path_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Home indicator", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_1", "11d021da-216e-4d80-b5b7-9ae24466b24c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "11d021da-216e-4d80-b5b7-9ae24466b24c"]] = ["Home indicator", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_8", "11d021da-216e-4d80-b5b7-9ae24466b24c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "11d021da-216e-4d80-b5b7-9ae24466b24c"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_9", "11d021da-216e-4d80-b5b7-9ae24466b24c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "11d021da-216e-4d80-b5b7-9ae24466b24c"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_10", "11d021da-216e-4d80-b5b7-9ae24466b24c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "11d021da-216e-4d80-b5b7-9ae24466b24c"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_11", "11d021da-216e-4d80-b5b7-9ae24466b24c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "11d021da-216e-4d80-b5b7-9ae24466b24c"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Paragraph_1", "11d021da-216e-4d80-b5b7-9ae24466b24c"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "11d021da-216e-4d80-b5b7-9ae24466b24c"]] = ["Title Button", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Path_8", "41289c69-39a6-44b5-897b-7a01aa0d8c44"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "41289c69-39a6-44b5-897b-7a01aa0d8c44"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_9", "41289c69-39a6-44b5-897b-7a01aa0d8c44"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "41289c69-39a6-44b5-897b-7a01aa0d8c44"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_10", "41289c69-39a6-44b5-897b-7a01aa0d8c44"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "41289c69-39a6-44b5-897b-7a01aa0d8c44"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_11", "41289c69-39a6-44b5-897b-7a01aa0d8c44"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "41289c69-39a6-44b5-897b-7a01aa0d8c44"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Paragraph_1", "41289c69-39a6-44b5-897b-7a01aa0d8c44"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "41289c69-39a6-44b5-897b-7a01aa0d8c44"]] = ["Title Button", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Path_1", "41289c69-39a6-44b5-897b-7a01aa0d8c44"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "41289c69-39a6-44b5-897b-7a01aa0d8c44"]] = ["Home indicator", "s-Path_1"]; 

	