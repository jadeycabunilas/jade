var content='<div class="ui-page " deviceName="androidgalaxys24plus" deviceType="mobile" deviceWidth="384" deviceHeight="832">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="393" height="852">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1730550615919.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-3a408e4f-eb1f-437b-9041-e985802234ee" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer commentable non-processed" alignment="left" name="CR"width="384" height="832">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/3a408e4f-eb1f-437b-9041-e985802234ee/style-1730550615919.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/3a408e4f-eb1f-437b-9041-e985802234ee/fonts-1730550615919.css" />\
      <div class="freeLayout">\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="Home Smart-Voice Control"   datasizewidth="281.44px" datasizeheight="24.00px" dataX="51.28" dataY="154.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">Home Smart-Voice Control</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext autofit firer ie-background commentable non-processed" customid="Comfort Room"   datasizewidth="122.45px" datasizeheight="19.00px" dataX="130.77" dataY="220.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Comfort Room</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer click ie-background commentable non-processed" customid="Image 1"   datasizewidth="33.00px" datasizeheight="26.00px" dataX="28.00" dataY="97.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/204cf2d0-ad8b-43cb-91fd-99d6a0076925.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Status bar" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Path_8" class="path firer commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="Wifi Icon"   datasizewidth="17.14px" datasizeheight="12.33px" dataX="84.00" dataY="22.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="17.141998291015625" height="12.328323364257812" viewBox="282.8580017089844 22.000000476837158 17.141998291015625 12.328323364257812" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_8-3a408" d="M291.42999267578125 24.466225147247314 C293.9169921875 24.46632432937622 296.3089904785156 25.388424396514893 298.1109924316406 27.04192590713501 C298.24700927734375 27.16962480545044 298.4639892578125 27.16802453994751 298.5979919433594 27.03832483291626 L299.8949890136719 25.774824619293213 C299.9629821777344 25.709125995635986 300.0 25.62002420425415 300.0 25.52732515335083 C299.9989929199219 25.434624195098877 299.96099853515625 25.346025943756104 299.8919982910156 25.281025409698486 C295.1610107421875 20.906324863433838 287.6969909667969 20.906324863433838 282.96600341796875 25.281025409698486 C282.89801025390625 25.345924854278564 282.8590087890625 25.434624195098877 282.8580017089844 25.527225971221924 C282.8580017089844 25.619925022125244 282.8949890136719 25.709024906158447 282.9629821777344 25.774824619293213 L284.260986328125 27.03832483291626 C284.39398193359375 27.16812562942505 284.6109924316406 27.169825077056885 284.74700927734375 27.04192590713501 C286.54998779296875 25.388325214385986 288.9419860839844 24.466225147247314 291.42999267578125 24.466225147247314 Z M291.4259948730469 28.68652582168579 C292.7829895019531 28.686424732208252 294.0920104980469 29.198225498199463 295.0979919433594 30.122324466705322 C295.2349853515625 30.253525257110596 295.4490051269531 30.250624179840088 295.5820007324219 30.115925312042236 L296.8689880371094 28.79662561416626 C296.93701171875 28.72742509841919 296.9739990234375 28.633524417877197 296.9729919433594 28.536024570465088 C296.97198486328125 28.438425540924072 296.9329833984375 28.34532594680786 296.8639831542969 28.277525424957275 C293.79998779296875 25.386724948883057 289.05499267578125 25.386724948883057 285.9909973144531 28.277525424957275 C285.9219970703125 28.34532594680786 285.88299560546875 28.438425540924072 285.8819885253906 28.536024570465088 C285.8809814453125 28.633625507354736 285.91900634765625 28.727524280548096 285.9859924316406 28.79662561416626 L287.27301025390625 30.115925312042236 C287.406005859375 30.250624179840088 287.6199951171875 30.253525257110596 287.7559814453125 30.122324466705322 C288.7619934082031 29.198824405670166 290.07000732421875 28.687124729156494 291.4259948730469 28.68652582168579 Z M293.95098876953125 31.480125904083252 C293.9530029296875 31.585426807403564 293.9150085449219 31.687023639678955 293.8479919433594 31.760826587677002 L291.6709899902344 34.21552324295044 C291.6080017089844 34.287724018096924 291.52099609375 34.32832384109497 291.42999267578125 34.32832384109497 C291.3389892578125 34.32832384109497 291.2519836425781 34.287724018096924 291.18798828125 34.21552324295044 L289.010986328125 31.760826587677002 C288.9440002441406 31.68692445755005 288.906982421875 31.585323810577393 288.90899658203125 31.480026721954346 C288.9110107421875 31.374626636505127 288.9519958496094 31.274925708770752 289.0220031738281 31.204224109649658 C290.4119873046875 29.890425205230713 292.447998046875 29.890425205230713 293.8379821777344 31.204224109649658 C293.9079895019531 31.274925708770752 293.9490051269531 31.374725818634033 293.95098876953125 31.480125904083252 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-3a408" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_9" class="path firer commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="Battery icon fill"   datasizewidth="21.00px" datasizeheight="9.00px" dataX="53.50" dataY="24.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="21.0" height="9.0" viewBox="309.5 24.0 21.0 9.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_9-3a408" d="M312.0 24.0 L328.0 24.0 C329.37145942588717 24.0 330.5 25.12854057411284 330.5 26.5 L330.5 30.5 C330.5 31.87145942588716 329.37145942588717 33.0 328.0 33.0 L312.0 33.0 C310.62854057411283 33.0 309.5 31.87145942588716 309.5 30.5 L309.5 26.5 C309.5 25.12854057411284 310.62854057411283 24.0 312.0 24.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_9-3a408" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_10" class="path firer commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="Battery Icon"   datasizewidth="27.33px" datasizeheight="13.00px" dataX="49.00" dataY="22.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="27.3280029296875" height="13.0" viewBox="307.6719970703125 22.0 27.3280029296875 13.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_10-3a408" d="M333.6719970703125 26.7811279296875 L333.6719970703125 30.856597900390625 C334.4766845703125 30.511428833007812 335.0 29.70846939086914 335.0 28.818859100341797 C335.0 27.92926025390625 334.4766845703125 27.126300811767578 333.6719970703125 26.7811279296875 Z M328.37200927734375 23.0 C330.1804504394531 23.0 331.6719970703125 24.49152374267578 331.6719970703125 26.299999237060547 L331.6719970703125 30.700000762939453 C331.6719970703125 32.50847625732422 330.1804504394531 34.0 328.37200927734375 34.0 L311.97198486328125 34.0 C310.1635437011719 34.0 308.6719970703125 32.50847625732422 308.6719970703125 30.700000762939453 L308.6719970703125 26.299999237060547 C308.6719970703125 24.49152374267578 310.1635437011719 23.0 311.97198486328125 23.0 Z M311.97198486328125 22.0 C309.6112365722656 22.0 307.6719970703125 23.939239501953125 307.6719970703125 26.299999237060547 L307.6719970703125 30.700000762939453 C307.6719970703125 33.060760498046875 309.6112365722656 35.0 311.97198486328125 35.0 L328.37200927734375 35.0 C330.7327575683594 35.0 332.6719970703125 33.060760498046875 332.6719970703125 30.700000762939453 L332.6719970703125 26.299999237060547 C332.6719970703125 23.939239501953125 330.7327575683594 22.0 328.37200927734375 22.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_10-3a408" fill="#FFFFFF" fill-opacity="1.0" opacity="0.4"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_11" class="path firer commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="Signal Icon"   datasizewidth="19.20px" datasizeheight="12.23px" dataX="109.00" dataY="22.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="19.20001220703125" height="12.226398468017578" viewBox="255.79998779296875 22.0 19.20001220703125 12.226398468017578" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_11-3a408" d="M275.0 23.146299362182617 C275.0 22.513198852539062 274.52197265625 22.0 273.9329833984375 22.0 L272.8669738769531 22.0 C272.2779846191406 22.0 271.79998779296875 22.513198852539062 271.79998779296875 23.146299362182617 L271.79998779296875 33.0802001953125 C271.79998779296875 33.71329879760742 272.2779846191406 34.22639846801758 272.8669738769531 34.22639846801758 L273.9329833984375 34.22639846801758 C274.52197265625 34.22639846801758 275.0 33.71329879760742 275.0 33.0802001953125 L275.0 23.146299362182617 Z M267.56597900390625 24.44529914855957 L268.63299560546875 24.44529914855957 C269.22198486328125 24.44529914855957 269.698974609375 24.97079849243164 269.698974609375 25.618999481201172 L269.698974609375 33.05270004272461 C269.698974609375 33.700897216796875 269.22198486328125 34.22639846801758 268.63299560546875 34.22639846801758 L267.56597900390625 34.22639846801758 C266.97698974609375 34.22639846801758 266.4989929199219 33.700897216796875 266.4989929199219 33.05270004272461 L266.4989929199219 25.618999481201172 C266.4989929199219 24.97079849243164 266.97698974609375 24.44529914855957 267.56597900390625 24.44529914855957 Z M263.2339782714844 27.094398498535156 L262.1669921875 27.094398498535156 C261.5780029296875 27.094398498535156 261.1009826660156 27.62649917602539 261.1009826660156 28.28299903869629 L261.1009826660156 33.03770065307617 C261.1009826660156 33.69419860839844 261.5780029296875 34.22639846801758 262.1669921875 34.22639846801758 L263.2339782714844 34.22639846801758 C263.822998046875 34.22639846801758 264.3009948730469 33.69419860839844 264.3009948730469 33.03770065307617 L264.3009948730469 28.28299903869629 C264.3009948730469 27.62649917602539 263.822998046875 27.094398498535156 263.2339782714844 27.094398498535156 Z M257.9329833984375 29.53959846496582 L256.8669738769531 29.53959846496582 C256.2779846191406 29.53959846496582 255.79998779296875 30.064199447631836 255.79998779296875 30.711299896240234 L255.79998779296875 33.0546989440918 C255.79998779296875 33.701900482177734 256.2779846191406 34.22639846801758 256.8669738769531 34.22639846801758 L257.9329833984375 34.22639846801758 C258.52197265625 34.22639846801758 259.0 33.701900482177734 259.0 33.0546989440918 L259.0 30.711299896240234 C259.0 30.064199447631836 258.52197265625 29.53959846496582 257.9329833984375 29.53959846496582 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_11-3a408" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_1" class="richtext autofit firer pageload ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="Clock"   datasizewidth="31.57px" datasizeheight="21.00px" dataX="49.00" dataY="17.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">9:41</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Path_1" class="path firer commentable pin vpin-end hpin-center non-processed-pin non-processed" customid="Home indicator"   datasizewidth="135.00px" datasizeheight="5.00px" dataX="0.00" dataY="23.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="135.0" height="5.0" viewBox="124.5 804.0 135.0 5.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-3a408" d="M127.0 804.0 L257.0 804.0 C258.37145942588717 804.0 259.5 805.1285405741129 259.5 806.5 L259.5 806.5 C259.5 807.8714594258871 258.37145942588717 809.0 257.0 809.0 L127.0 809.0 C125.62854057411285 809.0 124.5 807.8714594258871 124.5 806.5 L124.5 806.5 C124.5 805.1285405741129 125.62854057411285 804.0 127.0 804.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-3a408" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer click ie-background commentable non-processed" customid="Image 2"   datasizewidth="126.00px" datasizeheight="113.00px" dataX="129.00" dataY="334.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/93f97db8-2b05-4709-ba93-71d507823805.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_3" class="richtext autofit firer ie-background commentable hidden non-processed" customid="Listening..."   datasizewidth="92.02px" datasizeheight="20.00px" dataX="145.99" dataY="455.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">Listening...</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;