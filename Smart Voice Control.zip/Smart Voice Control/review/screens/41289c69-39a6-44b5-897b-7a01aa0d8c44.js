var content='<div class="ui-page " deviceName="androidgalaxys24plus" deviceType="mobile" deviceWidth="384" deviceHeight="832">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="393" height="852">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1730550615919.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-41289c69-39a6-44b5-897b-7a01aa0d8c44" class="screen growth-vertical devMobile devAndroid android-device galaxy-device canvas PORTRAIT firer commentable non-processed" alignment="left" name="Kitchen"width="384" height="832">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/41289c69-39a6-44b5-897b-7a01aa0d8c44/style-1730550615919.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/41289c69-39a6-44b5-897b-7a01aa0d8c44/fonts-1730550615919.css" />\
      <div class="freeLayout">\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="Home Smart-Voice Control"   datasizewidth="281.44px" datasizeheight="24.00px" dataX="51.28" dataY="154.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">Home Smart-Voice Control</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext autofit firer ie-background commentable non-processed" customid="Kitchen"   datasizewidth="64.33px" datasizeheight="19.00px" dataX="159.84" dataY="216.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Kitchen</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer click ie-background commentable non-processed" customid="Image 1"   datasizewidth="33.00px" datasizeheight="26.00px" dataX="28.00" dataY="97.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/204cf2d0-ad8b-43cb-91fd-99d6a0076925.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Status bar" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Path_8" class="path firer commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="Wifi Icon"   datasizewidth="17.14px" datasizeheight="12.33px" dataX="75.00" dataY="23.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="17.141998291015625" height="12.328323364257812" viewBox="291.8580017089844 23.000000476837158 17.141998291015625 12.328323364257812" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_8-41289" d="M300.42999267578125 25.466225147247314 C302.9169921875 25.46632432937622 305.3089904785156 26.388424396514893 307.1109924316406 28.04192590713501 C307.24700927734375 28.16962480545044 307.4639892578125 28.16802453994751 307.5979919433594 28.03832483291626 L308.8949890136719 26.774824619293213 C308.9629821777344 26.709125995635986 309.0 26.62002420425415 309.0 26.52732515335083 C308.9989929199219 26.434624195098877 308.96099853515625 26.346025943756104 308.8919982910156 26.281025409698486 C304.1610107421875 21.906324863433838 296.6969909667969 21.906324863433838 291.96600341796875 26.281025409698486 C291.89801025390625 26.345924854278564 291.8590087890625 26.434624195098877 291.8580017089844 26.527225971221924 C291.8580017089844 26.619925022125244 291.8949890136719 26.709024906158447 291.9629821777344 26.774824619293213 L293.260986328125 28.03832483291626 C293.39398193359375 28.16812562942505 293.6109924316406 28.169825077056885 293.74700927734375 28.04192590713501 C295.54998779296875 26.388325214385986 297.9419860839844 25.466225147247314 300.42999267578125 25.466225147247314 Z M300.4259948730469 29.68652582168579 C301.7829895019531 29.686424732208252 303.0920104980469 30.198225498199463 304.0979919433594 31.122324466705322 C304.2349853515625 31.253525257110596 304.4490051269531 31.250624179840088 304.5820007324219 31.115925312042236 L305.8689880371094 29.79662561416626 C305.93701171875 29.72742509841919 305.9739990234375 29.633524417877197 305.9729919433594 29.536024570465088 C305.97198486328125 29.438425540924072 305.9329833984375 29.34532594680786 305.8639831542969 29.277525424957275 C302.79998779296875 26.386724948883057 298.05499267578125 26.386724948883057 294.9909973144531 29.277525424957275 C294.9219970703125 29.34532594680786 294.88299560546875 29.438425540924072 294.8819885253906 29.536024570465088 C294.8809814453125 29.633625507354736 294.91900634765625 29.727524280548096 294.9859924316406 29.79662561416626 L296.27301025390625 31.115925312042236 C296.406005859375 31.250624179840088 296.6199951171875 31.253525257110596 296.7559814453125 31.122324466705322 C297.7619934082031 30.198824405670166 299.07000732421875 29.687124729156494 300.4259948730469 29.68652582168579 Z M302.95098876953125 32.48012590408325 C302.9530029296875 32.585426807403564 302.9150085449219 32.687023639678955 302.8479919433594 32.760826587677 L300.6709899902344 35.21552324295044 C300.6080017089844 35.287724018096924 300.52099609375 35.32832384109497 300.42999267578125 35.32832384109497 C300.3389892578125 35.32832384109497 300.2519836425781 35.287724018096924 300.18798828125 35.21552324295044 L298.010986328125 32.760826587677 C297.9440002441406 32.68692445755005 297.906982421875 32.58532381057739 297.90899658203125 32.480026721954346 C297.9110107421875 32.37462663650513 297.9519958496094 32.27492570877075 298.0220031738281 32.20422410964966 C299.4119873046875 30.890425205230713 301.447998046875 30.890425205230713 302.8379821777344 32.20422410964966 C302.9079895019531 32.27492570877075 302.9490051269531 32.37472581863403 302.95098876953125 32.48012590408325 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-41289" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_9" class="path firer commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="Battery icon fill"   datasizewidth="21.00px" datasizeheight="9.00px" dataX="44.50" dataY="25.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="21.0" height="9.0" viewBox="318.5 25.0 21.0 9.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_9-41289" d="M321.0 25.0 L337.0 25.0 C338.37145942588717 25.0 339.5 26.12854057411284 339.5 27.5 L339.5 31.5 C339.5 32.87145942588716 338.37145942588717 34.0 337.0 34.0 L321.0 34.0 C319.62854057411283 34.0 318.5 32.87145942588716 318.5 31.5 L318.5 27.5 C318.5 26.12854057411284 319.62854057411283 25.0 321.0 25.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_9-41289" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_10" class="path firer commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="Battery Icon"   datasizewidth="27.33px" datasizeheight="13.00px" dataX="40.00" dataY="23.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="27.3280029296875" height="13.0" viewBox="316.6719970703125 23.0 27.3280029296875 13.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_10-41289" d="M342.6719970703125 27.7811279296875 L342.6719970703125 31.856597900390625 C343.4766845703125 31.511428833007812 344.0 30.70846939086914 344.0 29.818859100341797 C344.0 28.92926025390625 343.4766845703125 28.126300811767578 342.6719970703125 27.7811279296875 Z M337.37200927734375 24.0 C339.1804504394531 24.0 340.6719970703125 25.49152374267578 340.6719970703125 27.299999237060547 L340.6719970703125 31.700000762939453 C340.6719970703125 33.50847625732422 339.1804504394531 35.0 337.37200927734375 35.0 L320.97198486328125 35.0 C319.1635437011719 35.0 317.6719970703125 33.50847625732422 317.6719970703125 31.700000762939453 L317.6719970703125 27.299999237060547 C317.6719970703125 25.49152374267578 319.1635437011719 24.0 320.97198486328125 24.0 Z M320.97198486328125 23.0 C318.6112365722656 23.0 316.6719970703125 24.939239501953125 316.6719970703125 27.299999237060547 L316.6719970703125 31.700000762939453 C316.6719970703125 34.060760498046875 318.6112365722656 36.0 320.97198486328125 36.0 L337.37200927734375 36.0 C339.7327575683594 36.0 341.6719970703125 34.060760498046875 341.6719970703125 31.700000762939453 L341.6719970703125 27.299999237060547 C341.6719970703125 24.939239501953125 339.7327575683594 23.0 337.37200927734375 23.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_10-41289" fill="#FFFFFF" fill-opacity="1.0" opacity="0.4"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_11" class="path firer commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="Signal Icon"   datasizewidth="19.20px" datasizeheight="12.23px" dataX="100.00" dataY="23.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="19.20001220703125" height="12.226398468017578" viewBox="264.79998779296875 23.0 19.20001220703125 12.226398468017578" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_11-41289" d="M284.0 24.146299362182617 C284.0 23.513198852539062 283.52197265625 23.0 282.9329833984375 23.0 L281.8669738769531 23.0 C281.2779846191406 23.0 280.79998779296875 23.513198852539062 280.79998779296875 24.146299362182617 L280.79998779296875 34.0802001953125 C280.79998779296875 34.71329879760742 281.2779846191406 35.22639846801758 281.8669738769531 35.22639846801758 L282.9329833984375 35.22639846801758 C283.52197265625 35.22639846801758 284.0 34.71329879760742 284.0 34.0802001953125 L284.0 24.146299362182617 Z M276.56597900390625 25.44529914855957 L277.63299560546875 25.44529914855957 C278.22198486328125 25.44529914855957 278.698974609375 25.97079849243164 278.698974609375 26.618999481201172 L278.698974609375 34.05270004272461 C278.698974609375 34.700897216796875 278.22198486328125 35.22639846801758 277.63299560546875 35.22639846801758 L276.56597900390625 35.22639846801758 C275.97698974609375 35.22639846801758 275.4989929199219 34.700897216796875 275.4989929199219 34.05270004272461 L275.4989929199219 26.618999481201172 C275.4989929199219 25.97079849243164 275.97698974609375 25.44529914855957 276.56597900390625 25.44529914855957 Z M272.2339782714844 28.094398498535156 L271.1669921875 28.094398498535156 C270.5780029296875 28.094398498535156 270.1009826660156 28.62649917602539 270.1009826660156 29.28299903869629 L270.1009826660156 34.03770065307617 C270.1009826660156 34.69419860839844 270.5780029296875 35.22639846801758 271.1669921875 35.22639846801758 L272.2339782714844 35.22639846801758 C272.822998046875 35.22639846801758 273.3009948730469 34.69419860839844 273.3009948730469 34.03770065307617 L273.3009948730469 29.28299903869629 C273.3009948730469 28.62649917602539 272.822998046875 28.094398498535156 272.2339782714844 28.094398498535156 Z M266.9329833984375 30.53959846496582 L265.8669738769531 30.53959846496582 C265.2779846191406 30.53959846496582 264.79998779296875 31.064199447631836 264.79998779296875 31.711299896240234 L264.79998779296875 34.0546989440918 C264.79998779296875 34.701900482177734 265.2779846191406 35.22639846801758 265.8669738769531 35.22639846801758 L266.9329833984375 35.22639846801758 C267.52197265625 35.22639846801758 268.0 34.701900482177734 268.0 34.0546989440918 L268.0 31.711299896240234 C268.0 31.064199447631836 267.52197265625 30.53959846496582 266.9329833984375 30.53959846496582 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_11-41289" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_1" class="richtext autofit firer pageload ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="Clock"   datasizewidth="31.57px" datasizeheight="21.00px" dataX="58.00" dataY="18.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">9:41</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Path_1" class="path firer commentable pin vpin-end hpin-center non-processed-pin non-processed" customid="Home indicator"   datasizewidth="135.00px" datasizeheight="5.00px" dataX="0.00" dataY="23.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="135.0" height="5.0" viewBox="124.5 804.0 135.0 5.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-41289" d="M127.0 804.0 L257.0 804.0 C258.37145942588717 804.0 259.5 805.1285405741129 259.5 806.5 L259.5 806.5 C259.5 807.8714594258871 258.37145942588717 809.0 257.0 809.0 L127.0 809.0 C125.62854057411285 809.0 124.5 807.8714594258871 124.5 806.5 L124.5 806.5 C124.5 805.1285405741129 125.62854057411285 804.0 127.0 804.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-41289" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer click ie-background commentable non-processed" customid="Image 2"   datasizewidth="126.00px" datasizeheight="113.00px" dataX="129.00" dataY="294.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/93f97db8-2b05-4709-ba93-71d507823805.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_3" class="richtext autofit firer ie-background commentable hidden non-processed" customid="Listening..."   datasizewidth="92.02px" datasizeheight="20.00px" dataX="145.99" dataY="415.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">Listening...</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;