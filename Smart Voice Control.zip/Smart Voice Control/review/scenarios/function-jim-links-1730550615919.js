(function(window, undefined) {

  var jimLinks = {
    "4d536289-6fea-4617-b499-a4e879f6eb5b" : {
      "Image_1" : [
        "11d021da-216e-4d80-b5b7-9ae24466b24c"
      ]
    },
    "3a408e4f-eb1f-437b-9041-e985802234ee" : {
      "Image_1" : [
        "11d021da-216e-4d80-b5b7-9ae24466b24c"
      ]
    },
    "1550d651-a200-4eaf-aba5-9a2aa9a1e732" : {
      "Image_1" : [
        "11d021da-216e-4d80-b5b7-9ae24466b24c"
      ]
    },
    "ddfaf0c8-9066-452b-8cef-df295962c9d3" : {
      "Image_1" : [
        "11d021da-216e-4d80-b5b7-9ae24466b24c"
      ]
    },
    "ca90d1c9-7c1f-4e09-8143-0defe2d7df92" : {
      "Image_1" : [
        "11d021da-216e-4d80-b5b7-9ae24466b24c"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Image_1" : [
        "11d021da-216e-4d80-b5b7-9ae24466b24c"
      ]
    },
    "11d021da-216e-4d80-b5b7-9ae24466b24c" : {
      "Image_1" : [
        "ca90d1c9-7c1f-4e09-8143-0defe2d7df92"
      ],
      "Image_2" : [
        "ddfaf0c8-9066-452b-8cef-df295962c9d3"
      ],
      "Image_3" : [
        "41289c69-39a6-44b5-897b-7a01aa0d8c44"
      ],
      "Image_4" : [
        "4d536289-6fea-4617-b499-a4e879f6eb5b"
      ],
      "Image_5" : [
        "3a408e4f-eb1f-437b-9041-e985802234ee"
      ],
      "Image_6" : [
        "1550d651-a200-4eaf-aba5-9a2aa9a1e732"
      ],
      "Image_7" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "41289c69-39a6-44b5-897b-7a01aa0d8c44" : {
      "Image_1" : [
        "11d021da-216e-4d80-b5b7-9ae24466b24c"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);